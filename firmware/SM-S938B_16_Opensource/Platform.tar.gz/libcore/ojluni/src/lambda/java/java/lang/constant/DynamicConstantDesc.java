/*
 * Copyright (c) 2018, 2021, Oracle and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.  Oracle designates this
 * particular file as subject to the "Classpath" exception as provided
 * by Oracle in the LICENSE file that accompanied this code.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Oracle, 500 Oracle Parkway, Redwood Shores, CA 94065 USA
 * or visit www.oracle.com if you need additional information or have any
 * questions.
 */
package java.lang.constant;

import java.lang.invoke.MethodHandles;
import java.util.List;

public abstract class DynamicConstantDesc<T>
        implements ConstantDesc {

    protected DynamicConstantDesc(DirectMethodHandleDesc bootstrapMethod,
                                  String constantName,
                                  ClassDesc constantType,
                                  ConstantDesc... bootstrapArgs) { }

    public static<T> ConstantDesc ofCanonical(DirectMethodHandleDesc bootstrapMethod,
                                              String constantName,
                                              ClassDesc constantType,
                                              ConstantDesc[] bootstrapArgs) { return null; }


    public static<T> DynamicConstantDesc<T> ofNamed(DirectMethodHandleDesc bootstrapMethod,
                                                    String constantName,
                                                    ClassDesc constantType,
                                                    ConstantDesc... bootstrapArgs) { return null; }

    public static<T> DynamicConstantDesc<T> of(DirectMethodHandleDesc bootstrapMethod,
                                               ConstantDesc... bootstrapArgs) { return null; }

    public static<T> DynamicConstantDesc<T> of(DirectMethodHandleDesc bootstrapMethod) {
        return null;
    }

    public String constantName() { return null; }

    public ClassDesc constantType() { return null; }

    public DirectMethodHandleDesc bootstrapMethod() { return null; }

    public ConstantDesc[] bootstrapArgs() { return null; }

    public List<ConstantDesc> bootstrapArgsList() { return null; }

    @SuppressWarnings("unchecked")
    public T resolveConstantDesc(MethodHandles.Lookup lookup) throws ReflectiveOperationException {
        return null;
    }

    @Override
    public final boolean equals(Object o) { return false; }

    @Override
    public final int hashCode() { return -1; }

    @Override
    public String toString() { return null; }
}
